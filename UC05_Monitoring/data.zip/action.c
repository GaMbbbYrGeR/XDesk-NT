Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("www.iana.org", 
		"URL=https://www.iana.org/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/_img/2015.1/fonts/NotoSans-Regular.woff", ENDITEM, 
		"Url=/_img/2015.1/fonts/NotoSans-Bold.woff", ENDITEM, 
		"Url=/_img/2015.1/fonts/NotoSans-Italic.woff", ENDITEM, 
		"Url=/_img/2015.1/iana-logo-homepage.svg", ENDITEM, 
		LAST);

	web_url("Domain Names", 
		"URL=https://www.iana.org/domains", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.iana.org/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}